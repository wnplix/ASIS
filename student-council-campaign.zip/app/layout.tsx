import type React from "react"
import type { Metadata } from "next"
import { Poppins } from "next/font/google"
import "./globals.css"
import { ThemeProvider } from "@/components/theme-provider"
import { FloatingBubbles } from "@/components/floating-bubbles"

const poppins = Poppins({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-poppins",
})

export const metadata: Metadata = {
  title: "ASIS - Acción Solidaria, Integración y Servicio",
  description: "Sitio web oficial de la campaña estudiantil ASIS para el Consejo Escolar del CEP Mixto Cristo Salvador",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="es" suppressHydrationWarning>
      <body className={poppins.className}>
        <ThemeProvider attribute="class" defaultTheme="light" enableSystem={false} disableTransitionOnChange>
          <FloatingBubbles />
          {children}
        </ThemeProvider>
      </body>
    </html>
  )
}
