"use client"

import { useEffect, useState } from "react"
import { motion } from "framer-motion"

export function FloatingBubbles() {
  const [bubbles, setBubbles] = useState<{ id: number; x: number; size: number; delay: number; color: string }[]>([])

  useEffect(() => {
    const newBubbles = Array.from({ length: 15 }, (_, i) => ({
      id: i,
      x: Math.random() * 100,
      size: Math.random() * 60 + 20,
      delay: Math.random() * 5,
      color: getRandomBlueColor(),
    }))
    setBubbles(newBubbles)
  }, [])

  const getRandomBlueColor = () => {
    const colors = [
      "bg-blue-200/30",
      "bg-blue-300/30",
      "bg-blue-400/30",
      "bg-sky-200/30",
      "bg-sky-300/30",
      "bg-cyan-200/30",
    ]
    return colors[Math.floor(Math.random() * colors.length)]
  }

  return (
    <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden">
      {bubbles.map((bubble) => (
        <motion.div
          key={bubble.id}
          className={`absolute rounded-full ${bubble.color}`}
          style={{
            left: `${bubble.x}%`,
            width: bubble.size,
            height: bubble.size,
          }}
          initial={{ y: "110vh" }}
          animate={{ y: "-20vh" }}
          transition={{
            duration: 15 + bubble.size / 10,
            repeat: Number.POSITIVE_INFINITY,
            delay: bubble.delay,
            ease: "linear",
          }}
        />
      ))}
    </div>
  )
}
