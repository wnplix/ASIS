"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import Image from "next/image"
import { motion } from "framer-motion"

interface TeamMemberProps {
  name: string
  role: string
  grade: string
  imageUrl: string
  funFact?: string
  emoji?: string
}

export function TeamMember({
  name,
  role,
  grade,
  imageUrl,
  funFact = "¡Me encanta ser parte de ASIS!",
  emoji = "😊",
}: TeamMemberProps) {
  const [isFlipped, setIsFlipped] = useState(false)

  return (
    <div className="perspective-1000">
      <motion.div
        className="w-full h-full relative preserve-3d cursor-pointer"
        animate={{ rotateY: isFlipped ? 180 : 0 }}
        transition={{ duration: 0.6 }}
        onClick={() => setIsFlipped(!isFlipped)}
        whileHover={{ scale: 1.02 }}
      >
        {/* Front of card */}
        <Card className="absolute w-full h-full backface-hidden overflow-hidden border-4 border-blue-200 rounded-2xl shadow-lg">
          <div className="relative h-64 w-full">
            <Image src={imageUrl || "/placeholder.svg?height=300&width=300"} alt={name} fill className="object-cover" />
            <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent"></div>
            <div className="absolute bottom-0 left-0 p-4 text-white">
              <p className="text-sm font-medium bg-blue-500 rounded-full px-3 py-1 inline-block">{grade}</p>
            </div>
            <div className="absolute top-2 right-2 bg-white rounded-full h-10 w-10 flex items-center justify-center text-xl shadow-md">
              {emoji}
            </div>
          </div>
          <CardContent className="p-4 bg-gradient-to-b from-white to-blue-50">
            <h3 className="font-bold text-lg text-blue-700">{name}</h3>
            <p className="text-blue-600 font-medium">{role}</p>
            <p className="text-xs text-muted-foreground mt-2">¡Haz clic para conocerme mejor! 👆</p>
          </CardContent>
        </Card>

        {/* Back of card */}
        <Card className="absolute w-full h-full backface-hidden overflow-hidden rotateY-180 border-4 border-blue-200 rounded-2xl shadow-lg bg-gradient-to-b from-blue-100 to-blue-50">
          <CardContent className="p-6 flex flex-col items-center justify-center h-full">
            <div className="text-4xl mb-4">{emoji}</div>
            <h3 className="font-bold text-lg text-blue-700 mb-2">{name}</h3>
            <div className="bg-white p-4 rounded-xl shadow-inner mb-4 w-full">
              <p className="text-center font-medium text-gray-700">"{funFact}"</p>
            </div>
            <p className="text-xs text-muted-foreground">¡Haz clic para volver! 👆</p>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  )
}
