"use client"

import { useEffect, useState } from "react"
import { motion } from "framer-motion"

export function Confetti() {
  const [pieces, setPieces] = useState<{ id: number; x: number; color: string; size: number; delay: number }[]>([])

  useEffect(() => {
    const colors = ["bg-blue-400", "bg-blue-500", "bg-blue-600", "bg-sky-400", "bg-sky-500", "bg-cyan-400"]

    const newPieces = Array.from({ length: 50 }, (_, i) => ({
      id: i,
      x: Math.random() * 100,
      color: colors[Math.floor(Math.random() * colors.length)],
      size: Math.random() * 8 + 4,
      delay: Math.random() * 5,
    }))

    setPieces(newPieces)
  }, [])

  return (
    <div className="absolute inset-0 pointer-events-none overflow-hidden">
      {pieces.map((piece) => (
        <motion.div
          key={piece.id}
          className={`absolute ${piece.color}`}
          style={{
            left: `${piece.x}%`,
            width: piece.size,
            height: piece.size,
            borderRadius: Math.random() > 0.5 ? "50%" : "0%",
          }}
          initial={{ y: "-10%", rotate: 0, opacity: 0 }}
          animate={{ y: "100%", rotate: 360, opacity: 1 }}
          transition={{ duration: 10, delay: piece.delay, repeat: Number.POSITIVE_INFINITY, repeatType: "loop" }}
        />
      ))}
    </div>
  )
}
