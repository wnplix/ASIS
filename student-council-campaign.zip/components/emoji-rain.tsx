"use client"

import { useEffect, useState } from "react"
import { motion } from "framer-motion"

export function EmojiRain() {
  const [emojis, setEmojis] = useState<{ id: number; emoji: string; x: number; delay: number; duration: number }[]>([])

  useEffect(() => {
    const emojiList = ["✨", "🌊", "💙", "🌈", "🍐", "🎨", "🎭", "🎪", "🎯", "🎮"]
    const newEmojis = Array.from({ length: 30 }, (_, i) => ({
      id: i,
      emoji: emojiList[Math.floor(Math.random() * emojiList.length)],
      x: Math.random() * 100,
      delay: Math.random() * 20,
      duration: Math.random() * 10 + 5,
    }))
    setEmojis(newEmojis)
  }, [])

  return (
    <div className="absolute inset-0 pointer-events-none overflow-hidden">
      {emojis.map((item) => (
        <motion.div
          key={item.id}
          className="absolute text-2xl"
          style={{
            left: `${item.x}%`,
            top: "-20px",
          }}
          initial={{ y: -20, rotate: 0, opacity: 1 }}
          animate={{ y: "110vh", rotate: 360, opacity: [0, 1, 1, 0] }}
          transition={{
            duration: item.duration,
            repeat: Number.POSITIVE_INFINITY,
            delay: item.delay,
            ease: "easeIn",
          }}
        >
          {item.emoji}
        </motion.div>
      ))}
    </div>
  )
}
