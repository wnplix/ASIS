import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import {
  Users,
  MessageSquare,
  Star,
  Zap,
  Trophy,
  Sparkles,
  Rocket,
  Heart,
  BookOpen,
  School,
  Pencil,
  PenTool,
} from "lucide-react"

export default function Home() {
  return (
    <div className="flex min-h-screen flex-col bg-blue-50">
      <header className="sticky top-0 z-40 border-b bg-white shadow-sm">
        <div className="container flex h-16 items-center justify-between py-4">
          <div className="flex items-center gap-2">
            <span className="text-xl font-bold text-blue-600">ASIS</span>
            <span className="hidden text-blue-500 sm:inline-block">Acción Solidaria, Integración y Servicio</span>
          </div>
          <nav className="flex items-center gap-4 sm:gap-6">
            <Link href="#objetivos" className="text-sm font-medium text-blue-600 hover:underline underline-offset-4">
              Objetivos
            </Link>
            <Link href="#candidatos" className="text-sm font-medium text-blue-600 hover:underline underline-offset-4">
              Candidatos
            </Link>
            <Link href="#propuestas" className="text-sm font-medium text-blue-600 hover:underline underline-offset-4">
              Propuestas
            </Link>
            <Link href="#mascota" className="text-sm font-medium text-blue-600 hover:underline underline-offset-4">
              Mascota
            </Link>
            <Button size="sm" className="bg-blue-600 hover:bg-blue-700">
              ¡Vota Ahora!
            </Button>
          </nav>
        </div>
      </header>
      <main className="flex-1">
        {/* Hero Section */}
        <section className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-r from-blue-600 to-blue-400 text-white">
          <div className="container px-4 md:px-6">
            <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 items-center">
              <div className="space-y-4">
                <div className="inline-block animate-bounce bg-white text-blue-600 px-3 py-1 rounded-full text-sm font-bold mb-2">
                  #AcciónSolidaria
                </div>
                <h1 className="text-4xl font-bold tracking-tighter sm:text-6xl">
                  ASIS: <span className="text-yellow-300">¡Dejando Huella!</span>
                </h1>
                <p className="max-w-[600px] text-blue-100 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  Acción Solidaria, Integración y Servicio. Trabajamos por un CEP Mixto Cristo Salvador más unido,
                  solidario y comprometido con el desarrollo integral de todos los estudiantes.
                </p>
                <div className="flex flex-col gap-2 min-[400px]:flex-row">
                  <Button size="lg" className="bg-yellow-400 text-blue-900 hover:bg-yellow-300">
                    <Zap className="mr-2 h-4 w-4" /> Únete a Nosotros
                  </Button>
                  <Button variant="outline" size="lg" className="text-white border-white hover:bg-blue-700">
                    <Star className="mr-2 h-4 w-4" /> Conoce Nuestras Propuestas
                  </Button>
                </div>
              </div>
              <div className="mx-auto w-full max-w-sm lg:max-w-none relative">
                <div className="absolute -top-6 -right-6 bg-yellow-400 text-blue-900 rounded-full p-4 rotate-12 font-bold z-10 shadow-lg">
                  ¡Vota por ASIS!
                </div>
                <Image
                  src="/placeholder.svg?height=400&width=400"
                  alt="Equipo ASIS"
                  width={400}
                  height={400}
                  className="aspect-square rounded-full object-cover border-4 border-white shadow-lg transform transition-transform hover:scale-105"
                />
              </div>
            </div>
          </div>
        </section>

        {/* Mascota Section */}
        <section
          id="mascota"
          className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-r from-blue-500 to-purple-500 text-white"
        >
          <div className="container px-4 md:px-6">
            <div className="grid gap-10 lg:grid-cols-2 items-center">
              <div className="space-y-4 order-2 lg:order-1">
                <div className="inline-block bg-white text-blue-600 px-3 py-1 rounded-full text-sm font-bold">
                  Conoce a Nuestra Mascota
                </div>
                <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl">¡Esnupi! 梨</h2>
                <p className="text-xl">
                  La mascota oficial del equipo, siempre está listo para darlo todo, dentro y fuera del campo.
                </p>
                <div className="space-y-4 bg-white/10 p-6 rounded-xl backdrop-blur-sm">
                  <h3 className="text-2xl font-bold text-yellow-300">Sobre Esnupi:</h3>
                  <p className="text-white/90">
                    Esnupi tiene vibes tranquilas y un corazón enorme. Le encanta jugar, pero más aún ver a su equipo
                    feliz, reírse juntos y animar a quien lo necesite. Para él, lo más importante no es ganar, sino que
                    todos se sientan parte de algo bonito.
                  </p>
                  <ul className="space-y-2">
                    <li className="flex items-start">
                      <Heart className="h-6 w-6 text-yellow-300 mr-2 flex-shrink-0 mt-0.5" />
                      <span>Es Cáncer e ISFJ</span>
                    </li>
                    <li className="flex items-start">
                      <Star className="h-6 w-6 text-yellow-300 mr-2 flex-shrink-0 mt-0.5" />
                      <span>Sus pelis favoritas son Toy Story, Mi Villano Favorito y Cómo entrenar a tu dragón</span>
                    </li>
                    <li className="flex items-start">
                      <Sparkles className="h-6 w-6 text-yellow-300 mr-2 flex-shrink-0 mt-0.5" />
                      <span>Sus series favoritas son Bluey y Foster's Home for Imaginary Friends</span>
                    </li>
                    <li className="flex items-start">
                      <MessageSquare className="h-6 w-6 text-yellow-300 mr-2 flex-shrink-0 mt-0.5" />
                      <span>Manda stickers de perritos tiernos porque sí y le gusta escribir en su diario</span>
                    </li>
                  </ul>
                  <p className="text-xl font-bold text-yellow-300 mt-4">"No solo jugamos, también dejamos huella."</p>
                  <p className="text-white/90">
                    Esnupi representa el compañerismo, el respeto y las ganas de seguir creciendo sin perder la esencia.
                    Esnupi es como tú, ¡busca cambios!
                  </p>
                </div>
                <Button className="bg-yellow-400 text-blue-900 hover:bg-yellow-300">
                  <Star className="mr-2 h-4 w-4" /> ¡Vota por ASIS y Esnupi!
                </Button>
              </div>
              <div className="relative mx-auto order-1 lg:order-2">
                <div className="absolute -top-6 -right-6 bg-yellow-400 text-blue-900 rounded-full p-4 rotate-12 font-bold z-10 shadow-lg animate-pulse">
                  ¡Dejando Huella!
                </div>
                <Image
                  src="/placeholder.svg?height=500&width=500"
                  alt="Esnupi"
                  width={500}
                  height={500}
                  className="rounded-xl border-4 border-white shadow-2xl transform transition-transform hover:rotate-3"
                />
                <div className="absolute -bottom-4 -left-4 bg-white text-blue-600 rounded-lg p-3 -rotate-6 font-bold shadow-lg">
                  ¡Vota por ASIS!
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Objetivos Section */}
        <section id="objetivos" className="w-full py-12 md:py-24 lg:py-32 bg-white">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <div className="inline-block bg-blue-100 text-blue-600 px-3 py-1 rounded-full text-sm font-bold">
                  Nuestros Objetivos
                </div>
                <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl text-blue-600">Plan de Trabajo ASIS</h2>
                <p className="max-w-[900px] text-blue-600/80 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  Trabajamos por la integración del alumnado escolar del CEP Mixto Cristo Salvador a través de
                  propuestas que llaman a la acción social, solidaria y al servicio de nuestros pares.
                </p>
              </div>
            </div>
            <div className="mx-auto grid max-w-5xl items-center gap-6 py-12 lg:grid-cols-2 lg:gap-12">
              <Image
                src="/placeholder.svg?height=400&width=600"
                alt="Equipo ASIS trabajando"
                width={600}
                height={400}
                className="mx-auto aspect-video overflow-hidden rounded-xl object-cover object-center sm:w-full lg:order-last shadow-lg transform transition-transform hover:rotate-2"
              />
              <div className="flex flex-col justify-center space-y-4">
                <div className="space-y-2">
                  <h3 className="text-2xl font-bold text-blue-600">Objetivo General</h3>
                  <p className="text-blue-600/80">
                    Integrar al alumnado escolar del CEP Mixto Cristo Salvador por medio de propuestas que llamen a la
                    acción social y solidaria, y al servicio de nuestros pares, relacionado con los valores capuchinos
                    de fraternidad y minoridad.
                  </p>
                </div>
                <div className="space-y-2 mt-6">
                  <h3 className="text-2xl font-bold text-blue-600">Objetivos Específicos</h3>
                  <ul className="grid gap-6">
                    <li className="bg-blue-50 p-4 rounded-lg transform transition-transform hover:scale-105">
                      <div className="grid gap-1">
                        <div className="flex items-center">
                          <Rocket className="h-6 w-6 text-blue-600 mr-2" />
                          <h3 className="text-xl font-bold text-blue-600">Mentalidad Emprendedora</h3>
                        </div>
                        <p className="text-blue-600/80">
                          Fomentar una mentalidad emprendedora y orientada hacia la proyección profesional, asistiendo
                          al alumno mediante insights y orientación.
                        </p>
                      </div>
                    </li>
                    <li className="bg-blue-50 p-4 rounded-lg transform transition-transform hover:scale-105">
                      <div className="grid gap-1">
                        <div className="flex items-center">
                          <BookOpen className="h-6 w-6 text-blue-600 mr-2" />
                          <h3 className="text-xl font-bold text-blue-600">Sistemas de Aprendizaje</h3>
                        </div>
                        <p className="text-blue-600/80">
                          Implementar sistemas de aprendizaje y retroalimentación sostenidos por los propios alumnos,
                          promoviendo el desarrollo de habilidades blandas y talentos.
                        </p>
                      </div>
                    </li>
                    <li className="bg-blue-50 p-4 rounded-lg transform transition-transform hover:scale-105">
                      <div className="grid gap-1">
                        <div className="flex items-center">
                          <Sparkles className="h-6 w-6 text-blue-600 mr-2" />
                          <h3 className="text-xl font-bold text-blue-600">Potenciar Recursos</h3>
                        </div>
                        <p className="text-blue-600/80">
                          Potenciar los recursos vigentes en el colegio y gestionar nuevos apoyos que beneficien
                          directamente a la comunidad para una vida estudiantil más enriquecedora.
                        </p>
                      </div>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Candidatos Section */}
        <section id="candidatos" className="w-full py-12 md:py-24 lg:py-32 bg-blue-600 text-white">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <div className="inline-block bg-white text-blue-600 px-3 py-1 rounded-full text-sm font-bold">
                  Nuestro Equipo
                </div>
                <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl">Candidatos al Consejo Escolar</h2>
                <p className="max-w-[900px] text-blue-100 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  Conoce a los estudiantes comprometidos que forman parte de nuestra lista para el Consejo Escolar.
                </p>
              </div>
            </div>
            <div className="mx-auto grid max-w-5xl items-start gap-6 py-12 md:grid-cols-2 lg:grid-cols-3">
              <Card className="bg-white border-none shadow-lg transform transition-transform hover:scale-105">
                <CardContent className="pt-6">
                  <div className="flex flex-col items-center space-y-4 text-center">
                    <div className="h-24 w-24 rounded-full bg-blue-100 flex items-center justify-center">
                      <Image
                        src="/placeholder.svg?height=96&width=96"
                        alt="Gabriel Córdova"
                        width={96}
                        height={96}
                        className="rounded-full"
                      />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-blue-600">Gabriel Córdova Alcázar</h3>
                      <p className="text-blue-600/80">Presidente</p>
                      <p className="text-blue-600/60 text-sm">5to "A"</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card className="bg-white border-none shadow-lg transform transition-transform hover:scale-105">
                <CardContent className="pt-6">
                  <div className="flex flex-col items-center space-y-4 text-center">
                    <div className="h-24 w-24 rounded-full bg-blue-100 flex items-center justify-center">
                      <Image
                        src="/placeholder.svg?height=96&width=96"
                        alt="Eduardo Sánchez"
                        width={96}
                        height={96}
                        className="rounded-full"
                      />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-blue-600">Eduardo Jesus Sánchez Bernui</h3>
                      <p className="text-blue-600/80">Vicepresidente</p>
                      <p className="text-blue-600/60 text-sm">5to "A"</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card className="bg-white border-none shadow-lg transform transition-transform hover:scale-105">
                <CardContent className="pt-6">
                  <div className="flex flex-col items-center space-y-4 text-center">
                    <div className="h-24 w-24 rounded-full bg-blue-100 flex items-center justify-center">
                      <Image
                        src="/placeholder.svg?height=96&width=96"
                        alt="Silvana Vigo"
                        width={96}
                        height={96}
                        className="rounded-full"
                      />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-blue-600">Silvana Alejandra Vigo Calderon</h3>
                      <p className="text-blue-600/80">Secretario</p>
                      <p className="text-blue-600/60 text-sm">5to "B"</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card className="bg-white border-none shadow-lg transform transition-transform hover:scale-105">
                <CardContent className="pt-6">
                  <div className="flex flex-col items-center space-y-4 text-center">
                    <div className="h-24 w-24 rounded-full bg-blue-100 flex items-center justify-center">
                      <Image
                        src="/placeholder.svg?height=96&width=96"
                        alt="Frine Durand"
                        width={96}
                        height={96}
                        className="rounded-full"
                      />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-blue-600">Frine Oriana Durand Coronel</h3>
                      <p className="text-blue-600/80">Delegado de cultura, recreación y deporte</p>
                      <p className="text-blue-600/60 text-sm">2do "A"</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card className="bg-white border-none shadow-lg transform transition-transform hover:scale-105">
                <CardContent className="pt-6">
                  <div className="flex flex-col items-center space-y-4 text-center">
                    <div className="h-24 w-24 rounded-full bg-blue-100 flex items-center justify-center">
                      <Image
                        src="/placeholder.svg?height=96&width=96"
                        alt="Mikela Puertas"
                        width={96}
                        height={96}
                        className="rounded-full"
                      />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-blue-600">Mikela Ariana Puertas Díaz</h3>
                      <p className="text-blue-600/80">Delegado de ecología y conservación ambiental</p>
                      <p className="text-blue-600/60 text-sm">3ro "B"</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card className="bg-white border-none shadow-lg transform transition-transform hover:scale-105">
                <CardContent className="pt-6">
                  <div className="flex flex-col items-center space-y-4 text-center">
                    <div className="h-24 w-24 rounded-full bg-blue-100 flex items-center justify-center">
                      <Image
                        src="/placeholder.svg?height=96&width=96"
                        alt="Grecia Medina"
                        width={96}
                        height={96}
                        className="rounded-full"
                      />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-blue-600">Grecia Camila Medina Sulca</h3>
                      <p className="text-blue-600/80">Delegado de Pastoral</p>
                      <p className="text-blue-600/60 text-sm">4to "B"</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Propuestas Section */}
        <section id="propuestas" className="w-full py-12 md:py-24 lg:py-32 bg-white">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <div className="inline-block bg-blue-100 text-blue-600 px-3 py-1 rounded-full text-sm font-bold">
                  Nuestras Propuestas
                </div>
                <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl text-blue-600">Plan de Acción ASIS</h2>
                <p className="max-w-[900px] text-blue-600/80 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  Conoce nuestras propuestas para mejorar la vida estudiantil en el CEP Mixto Cristo Salvador.
                </p>
              </div>
            </div>

            {/* Tabs for different proposal categories */}
            <div className="mx-auto max-w-5xl py-8">
              <div className="flex flex-wrap justify-center gap-4 mb-8">
                <Button className="bg-blue-600 hover:bg-blue-700">Colegio en General</Button>
                <Button variant="outline" className="text-blue-600 border-blue-600 hover:bg-blue-100">
                  6to Primaria - 5to Secundaria
                </Button>
                <Button variant="outline" className="text-blue-600 border-blue-600 hover:bg-blue-100">
                  Inicial - 5to Primaria
                </Button>
              </div>

              {/* General School Proposals */}
              <div className="space-y-8">
                <div className="group rounded-xl bg-blue-50 p-6 shadow-lg transition-all hover:bg-blue-100">
                  <div className="space-y-4">
                    <div className="flex items-center">
                      <div className="flex h-12 w-12 items-center justify-center rounded-full bg-blue-600 text-white">
                        <PenTool className="h-6 w-6" />
                      </div>
                      <h3 className="ml-4 text-2xl font-bold text-blue-600">
                        Creación de Nuevos Clubes Extracurriculares
                      </h3>
                    </div>
                    <p className="text-blue-600/80">
                      Proponemos formalizar y expandir la creación de clubes extracurriculares quincenales para que más
                      estudiantes puedan desarrollar sus talentos, pasiones e intereses. Esperamos que los clubes se
                      concreten en Junio.
                    </p>
                    <div className="space-y-2">
                      <h4 className="font-bold text-blue-600">Clubes a implementar:</h4>
                      <p className="text-blue-600/80">
                        Los primeros clubes estarán centrados en actividades creativas como teatro, danza y arte. Se
                        realizará una asamblea para conocer los intereses del alumnado y determinar qué clubes
                        implementar.
                      </p>
                      <h4 className="font-bold text-blue-600">Impacto:</h4>
                      <p className="text-blue-600/80">
                        Estos espacios estimularán la creatividad y el aprendizaje colaborativo, fortalecerán los lazos
                        de amistad, reducirán el estrés escolar y crearán una comunidad más viva y diversa.
                      </p>
                    </div>
                  </div>
                </div>

                <div className="group rounded-xl bg-blue-50 p-6 shadow-lg transition-all hover:bg-blue-100">
                  <div className="space-y-4">
                    <div className="flex items-center">
                      <div className="flex h-12 w-12 items-center justify-center rounded-full bg-blue-600 text-white">
                        <Sparkles className="h-6 w-6" />
                      </div>
                      <h3 className="ml-4 text-2xl font-bold text-blue-600">
                        Obra Musical para Fomentar el Talento Estudiantil
                      </h3>
                    </div>
                    <p className="text-blue-600/80">
                      Proponemos la creación de una obra musical navideña como evento de cierre del año escolar,
                      reuniendo a los distintos talleres extracurriculares del colegio en una gran puesta en escena.
                    </p>
                    <div className="space-y-2">
                      <h4 className="font-bold text-blue-600">Objetivo General:</h4>
                      <p className="text-blue-600/80">
                        Sentar las bases para que los talleres artísticos del colegio colaboren en la realización de una
                        obra musical navideña que permita demostrar los conocimientos adquiridos y fortalecer el sentido
                        de comunidad.
                      </p>
                      <h4 className="font-bold text-blue-600">Etapas:</h4>
                      <ul className="ml-6 list-disc text-blue-600/80 space-y-1">
                        <li>Planificación General (Primera Semana de Septiembre)</li>
                        <li>Creación del Guion y Diseño Artístico (Segunda Semana de Septiembre)</li>
                        <li>Ensayos Individuales por Taller (Finales de Septiembre – Octubre)</li>
                        <li>Ensayos Integrados (Noviembre)</li>
                        <li>Presentación Final (Clausura del año escolar)</li>
                      </ul>
                    </div>
                  </div>
                </div>

                <div className="group rounded-xl bg-blue-50 p-6 shadow-lg transition-all hover:bg-blue-100">
                  <div className="space-y-4">
                    <div className="flex items-center">
                      <div className="flex h-12 w-12 items-center justify-center rounded-full bg-blue-600 text-white">
                        <Trophy className="h-6 w-6" />
                      </div>
                      <h3 className="ml-4 text-2xl font-bold text-blue-600">Gymkhana</h3>
                    </div>
                    <p className="text-blue-600/80">
                      Proponemos retomar y modernizar las gymkanas como cierre de bimestre entre promociones, fomentando
                      el compañerismo, la sana competencia y el espíritu escolar.
                    </p>
                    <div className="space-y-2">
                      <h4 className="font-bold text-blue-600">Objetivo General:</h4>
                      <p className="text-blue-600/80">
                        Reactivar y dinamizar las actividades deportivas dentro del colegio mediante la organización
                        periódica de gymkanas entre promociones, fortaleciendo los lazos entre estudiantes.
                      </p>
                      <h4 className="font-bold text-blue-600">Estructura:</h4>
                      <p className="text-blue-600/80">
                        Las gymkanas se realizarán al término de bimestre, con pruebas que combinarán habilidades
                        físicas, trabajo en equipo, coordinación y rapidez mental.
                      </p>
                    </div>
                  </div>
                </div>

                <div className="group rounded-xl bg-blue-50 p-6 shadow-lg transition-all hover:bg-blue-100">
                  <div className="space-y-4">
                    <div className="flex items-center">
                      <div className="flex h-12 w-12 items-center justify-center rounded-full bg-blue-600 text-white">
                        <MessageSquare className="h-6 w-6" />
                      </div>
                      <h3 className="ml-4 text-2xl font-bold text-blue-600">Mural Estudiantil</h3>
                    </div>
                    <p className="text-blue-600/80">
                      Crear un espacio visible y dinámico dentro del colegio, ya sea a través de un mural físico o una
                      pantalla digital interactiva, para difundir información de manera accesible, atractiva y siempre
                      actualizada.
                    </p>
                    <div className="space-y-2">
                      <h4 className="font-bold text-blue-600">Contenido:</h4>
                      <ul className="ml-6 list-disc text-blue-600/80 space-y-1">
                        <li>Comunicados Oficiales</li>
                        <li>Fechas Importantes</li>
                        <li>Convocatorias y Concursos</li>
                        <li>Reconocimientos a Logros Estudiantiles</li>
                        <li>Cumpleaños de la Semana</li>
                        <li>Campañas de Visibilización por Área</li>
                      </ul>
                    </div>
                  </div>
                </div>

                <div className="group rounded-xl bg-blue-50 p-6 shadow-lg transition-all hover:bg-blue-100">
                  <div className="space-y-4">
                    <div className="flex items-center">
                      <div className="flex h-12 w-12 items-center justify-center rounded-full bg-blue-600 text-white">
                        <Pencil className="h-6 w-6" />
                      </div>
                      <h3 className="ml-4 text-2xl font-bold text-blue-600">Anuario Estudiantil Digital</h3>
                    </div>
                    <p className="text-blue-600/80">
                      Difundir de manera mensual las actividades escolares destacando la participación de los
                      estudiantes a través de fotografías en una revista digital.
                    </p>
                    <div className="space-y-2">
                      <h4 className="font-bold text-blue-600">Descripción:</h4>
                      <p className="text-blue-600/80">
                        Similar al periódico estudiantil, el Anuario Estudiantil Digital será una revista mensual que
                        recopilará las fotos de eventos, actividades académicas, deportivas, culturales y momentos clave
                        del mes.
                      </p>
                      <p className="text-blue-600/80">
                        Este anuario no solo servirá como un medio de difusión, sino también como una forma de mostrar
                        la unidad y el sentido de comunidad dentro del colegio.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Secondary School Proposals Preview */}
            <div className="mx-auto max-w-5xl py-8 border-t border-blue-200">
              <h3 className="text-2xl font-bold text-blue-600 mb-6 text-center">
                Propuestas para 6to de Primaria a 5to de Secundaria
              </h3>
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                <Card className="bg-blue-50 border-none shadow-lg transform transition-transform hover:scale-105">
                  <CardContent className="p-6">
                    <div className="flex flex-col space-y-4">
                      <div className="rounded-full bg-blue-100 p-3 w-12 h-12 flex items-center justify-center">
                        <BookOpen className="h-6 w-6 text-blue-600" />
                      </div>
                      <h3 className="text-xl font-bold text-blue-600">Periódico Escolar Semanal</h3>
                      <p className="text-blue-600/80">
                        El periódico estudiantil oficial del Colegio Cristo Salvador, un foro público para la expresión
                        estudiantil.
                      </p>
                      <Button className="bg-blue-600 hover:bg-blue-700 w-full">Ver Detalles</Button>
                    </div>
                  </CardContent>
                </Card>
                <Card className="bg-blue-50 border-none shadow-lg transform transition-transform hover:scale-105">
                  <CardContent className="p-6">
                    <div className="flex flex-col space-y-4">
                      <div className="rounded-full bg-blue-100 p-3 w-12 h-12 flex items-center justify-center">
                        <Zap className="h-6 w-6 text-blue-600" />
                      </div>
                      <h3 className="text-xl font-bold text-blue-600">Canal Estudiantil</h3>
                      <p className="text-blue-600/80">
                        Espacio oficial de noticias audiovisuales presentado por y para estudiantes, con emisiones
                        mensuales.
                      </p>
                      <Button className="bg-blue-600 hover:bg-blue-700 w-full">Ver Detalles</Button>
                    </div>
                  </CardContent>
                </Card>
                <Card className="bg-blue-50 border-none shadow-lg transform transition-transform hover:scale-105">
                  <CardContent className="p-6">
                    <div className="flex flex-col space-y-4">
                      <div className="rounded-full bg-blue-100 p-3 w-12 h-12 flex items-center justify-center">
                        <Users className="h-6 w-6 text-blue-600" />
                      </div>
                      <h3 className="text-xl font-bold text-blue-600">Red de Estudiantes</h3>
                      <p className="text-blue-600/80">
                        Iniciativa para fortalecer el aprendizaje colaborativo y la solidaridad académica entre alumnos.
                      </p>
                      <Button className="bg-blue-600 hover:bg-blue-700 w-full">Ver Detalles</Button>
                    </div>
                  </CardContent>
                </Card>
              </div>
              <div className="flex justify-center mt-8">
                <Button variant="outline" className="text-blue-600 border-blue-600 hover:bg-blue-100">
                  Ver Todas las Propuestas
                </Button>
              </div>
            </div>

            {/* Primary School Proposals Preview */}
            <div className="mx-auto max-w-5xl py-8 border-t border-blue-200">
              <h3 className="text-2xl font-bold text-blue-600 mb-6 text-center">
                Propuestas para Inicial a 5to de Primaria
              </h3>
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                <Card className="bg-blue-50 border-none shadow-lg transform transition-transform hover:scale-105">
                  <CardContent className="p-6">
                    <div className="flex flex-col space-y-4">
                      <div className="rounded-full bg-blue-100 p-3 w-12 h-12 flex items-center justify-center">
                        <School className="h-6 w-6 text-blue-600" />
                      </div>
                      <h3 className="text-xl font-bold text-blue-600">Yo Quiero Ser</h3>
                      <p className="text-blue-600/80">
                        Actividad especial para el Día del Maestro donde los estudiantes se disfrazan de lo que quieren
                        ser de grandes.
                      </p>
                      <Button className="bg-blue-600 hover:bg-blue-700 w-full">Ver Detalles</Button>
                    </div>
                  </CardContent>
                </Card>
                <Card className="bg-blue-50 border-none shadow-lg transform transition-transform hover:scale-105">
                  <CardContent className="p-6">
                    <div className="flex flex-col space-y-4">
                      <div className="rounded-full bg-blue-100 p-3 w-12 h-12 flex items-center justify-center">
                        <Sparkles className="h-6 w-6 text-blue-600" />
                      </div>
                      <h3 className="text-xl font-bold text-blue-600">Open House Salvadorino</h3>
                      <p className="text-blue-600/80">
                        Día de puertas abiertas donde alumnos representan íconos de la cultura popular británica.
                      </p>
                      <Button className="bg-blue-600 hover:bg-blue-700 w-full">Ver Detalles</Button>
                    </div>
                  </CardContent>
                </Card>
                <Card className="bg-blue-50 border-none shadow-lg transform transition-transform hover:scale-105">
                  <CardContent className="p-6">
                    <div className="flex flex-col space-y-4">
                      <div className="rounded-full bg-blue-100 p-3 w-12 h-12 flex items-center justify-center">
                        <Rocket className="h-6 w-6 text-blue-600" />
                      </div>
                      <h3 className="text-xl font-bold text-blue-600">Divercity: Un Mundo de Vocaciones</h3>
                      <p className="text-blue-600/80">
                        Experiencia inmersiva donde los alumnos pueden ser partícipes de distintas carreras.
                      </p>
                      <Button className="bg-blue-600 hover:bg-blue-700 w-full">Ver Detalles</Button>
                    </div>
                  </CardContent>
                </Card>
              </div>
              <div className="flex justify-center mt-8">
                <Button variant="outline" className="text-blue-600 border-blue-600 hover:bg-blue-100">
                  Ver Todas las Propuestas
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section
          id="contact"
          className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-r from-blue-600 to-purple-600 text-white"
        >
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <div className="inline-block animate-bounce bg-yellow-400 text-blue-900 px-3 py-1 rounded-full text-sm font-bold mb-2">
                  ¡Tu Voto Cuenta!
                </div>
                <h2 className="text-4xl font-bold tracking-tighter sm:text-6xl">
                  ¿Listo para <span className="text-yellow-300">Dejar Huella?</span>
                </h2>
                <p className="max-w-[900px] md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  Vota por ASIS: Acción Solidaria, Integración y Servicio para un mejor CEP Mixto Cristo Salvador.
                </p>
              </div>
              <div className="flex flex-col gap-2 min-[400px]:flex-row">
                <Button size="lg" className="bg-yellow-400 text-blue-900 hover:bg-yellow-300">
                  <Star className="mr-2 h-5 w-5" /> ¡Vota por ASIS!
                </Button>
                <Button variant="outline" size="lg" className="text-white border-white hover:bg-blue-700">
                  <Users className="mr-2 h-5 w-5" /> Únete a Nuestro Equipo
                </Button>
              </div>
            </div>
          </div>
        </section>
      </main>
      <footer className="w-full border-t bg-white py-6">
        <div className="container flex flex-col items-center justify-center gap-4 px-4 md:px-6 md:flex-row md:justify-between">
          <div className="flex items-center gap-2">
            <span className="font-bold text-blue-600">ASIS</span>
            <span className="text-blue-500">Acción Solidaria, Integración y Servicio</span>
          </div>
          <p className="text-center text-sm text-blue-500 md:text-left">
            &copy; {new Date().getFullYear()} Campaña ASIS. Todos los derechos reservados.
          </p>
          <div className="flex gap-4">
            <Link href="#" className="text-sm text-blue-500 hover:underline">
              Contacto
            </Link>
            <Link href="#" className="text-sm text-blue-500 hover:underline">
              Propuestas Completas
            </Link>
          </div>
        </div>
      </footer>
    </div>
  )
}
