import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { ChevronRight, Heart, MessageCircle, Star } from "lucide-react"
import { ProposalCard } from "@/components/proposal-card"
import { HeroSection } from "@/components/hero-section"
import { EmojiRain } from "@/components/emoji-rain"
import { FunHeader } from "@/components/fun-header"
import { Confetti } from "@/components/confetti"

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      <FunHeader />
      <main className="flex-1">
        <section id="inicio" className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-b from-blue-50 to-white relative">
          <EmojiRain />
          <HeroSection />
        </section>

        <section
          id="conocenos"
          className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-b from-blue-50 to-white relative"
        >
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <Badge className="bg-gradient-to-r from-blue-400 to-blue-600 text-white hover:from-blue-500 hover:to-blue-700">
                  Nuestro Equipo
                </Badge>
                <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl bg-clip-text text-transparent bg-gradient-to-r from-blue-500 to-blue-600">
                  Conoce a ASIS
                </h2>
                <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  Conoce a los integrantes que están trabajando para hacer la diferencia en nuestro colegio.
                </p>
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mt-12">
              <div className="bg-blue-100/50 rounded-xl p-6 border-2 border-blue-200 flex flex-col items-center text-center space-y-4 hover:bg-blue-100/70 transition-all duration-300">
                <div className="w-32 h-32 rounded-full overflow-hidden border-4 border-white">
                  <Image
                    src="/images/gabriel.jpg"
                    alt="Gabriel Córdova"
                    width={128}
                    height={128}
                    className="object-cover"
                  />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-blue-700">Gabriel Córdova Alcázar</h3>
                  <p className="text-blue-600">Presidente</p>
                  <p className="text-sm text-blue-500 mt-1">5to "A"</p>
                </div>
              </div>
              <div className="bg-blue-100/50 rounded-xl p-6 border-2 border-blue-200 flex flex-col items-center text-center space-y-4 hover:bg-blue-100/70 transition-all duration-300">
                <div className="w-32 h-32 rounded-full overflow-hidden border-4 border-white">
                  <Image
                    src="/images/eduardo.jpg"
                    alt="Eduardo Sánchez"
                    width={128}
                    height={128}
                    className="object-cover"
                  />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-blue-700">Eduardo Jesus Sánchez Bernui</h3>
                  <p className="text-blue-600">Vicepresidente</p>
                  <p className="text-sm text-blue-500 mt-1">5to "A"</p>
                </div>
              </div>
              <div className="bg-blue-100/50 rounded-xl p-6 border-2 border-blue-200 flex flex-col items-center text-center space-y-4 hover:bg-blue-100/70 transition-all duration-300">
                <div className="w-32 h-32 rounded-full overflow-hidden border-4 border-white">
                  <Image
                    src="/images/silvana.jpg"
                    alt="Silvana Vigo"
                    width={128}
                    height={128}
                    className="object-cover"
                  />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-blue-700">Silvana Alejandra Vigo Calderon</h3>
                  <p className="text-blue-600">Secretaria</p>
                  <p className="text-sm text-blue-500 mt-1">5to "B"</p>
                </div>
              </div>
              <div className="bg-blue-100/50 rounded-xl p-6 border-2 border-blue-200 flex flex-col items-center text-center space-y-4 hover:bg-blue-100/70 transition-all duration-300">
                <div className="w-32 h-32 rounded-full overflow-hidden border-4 border-white">
                  <Image
                    src="/images/oriana.jpg"
                    alt="Frine Durand"
                    width={128}
                    height={128}
                    className="object-cover"
                  />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-blue-700">Frine Oriana Durand Coronel</h3>
                  <p className="text-blue-600">Delegada de cultura, recreación y deporte</p>
                  <p className="text-sm text-blue-500 mt-1">2do "A"</p>
                </div>
              </div>
              <div className="bg-blue-100/50 rounded-xl p-6 border-2 border-blue-200 flex flex-col items-center text-center space-y-4 hover:bg-blue-100/70 transition-all duration-300">
                <div className="w-32 h-32 rounded-full overflow-hidden border-4 border-white">
                  <Image
                    src="/images/mikela.jpg"
                    alt="Mikela Puertas"
                    width={128}
                    height={128}
                    className="object-cover"
                  />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-blue-700">Mikela Ariana Puertas Díaz</h3>
                  <p className="text-blue-600">Delegada de ecología y conservación ambiental</p>
                  <p className="text-sm text-blue-500 mt-1">3ro "B"</p>
                </div>
              </div>
              <div className="bg-blue-100/50 rounded-xl p-6 border-2 border-blue-200 flex flex-col items-center text-center space-y-4 hover:bg-blue-100/70 transition-all duration-300">
                <div className="w-32 h-32 rounded-full overflow-hidden border-4 border-white">
                  <Image
                    src="/images/grecia.jpg"
                    alt="Grecia Medina"
                    width={128}
                    height={128}
                    className="object-cover"
                  />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-blue-700">Grecia Camila Medina Sulca</h3>
                  <p className="text-blue-600">Delegada de Pastoral</p>
                  <p className="text-sm text-blue-500 mt-1">4to "B"</p>
                </div>
              </div>
            </div>
            <div className="mt-16 space-y-8">
              <div className="flex flex-col items-center justify-center space-y-4 text-center">
                <div className="space-y-2">
                  <h3 className="text-2xl font-bold">Nuestros Objetivos</h3>
                  <p className="max-w-[900px] text-muted-foreground">
                    Nuestro plan tiene como objetivo general la integración del alumnado escolar del CEP Mixto Cristo
                    Salvador por medio de propuestas que llamen a la acción social y solidaria, y al servicio de
                    nuestros pares.
                  </p>
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <Card className="hover:shadow-lg transition-all duration-200 hover:-translate-y-1 border-2 border-dashed border-blue-200 rounded-3xl overflow-hidden">
                  <CardContent className="p-6 flex flex-col items-center text-center space-y-4">
                    <div className="rounded-full bg-blue-100 p-3 animate-bounce">
                      <Heart className="h-6 w-6 text-blue-600" />
                    </div>
                    <h4 className="text-xl font-bold">Solidaridad</h4>
                    <p className="text-muted-foreground">
                      Trabajamos juntos para apoyarnos mutuamente y crear un ambiente escolar inclusivo.
                    </p>
                  </CardContent>
                </Card>
                <Card className="hover:shadow-lg transition-all duration-200 hover:-translate-y-1 border-2 border-dashed border-blue-200 rounded-3xl overflow-hidden">
                  <CardContent className="p-6 flex flex-col items-center text-center space-y-4">
                    <div className="rounded-full bg-blue-100 p-3 animate-wiggle">
                      <MessageCircle className="h-6 w-6 text-blue-600" />
                    </div>
                    <h4 className="text-xl font-bold">Integración</h4>
                    <p className="text-muted-foreground">
                      Creemos en unir a todos los estudiantes, valorando nuestras diferencias y fortalezas.
                    </p>
                  </CardContent>
                </Card>
                <Card className="hover:shadow-lg transition-all duration-200 hover:-translate-y-1 border-2 border-dashed border-blue-200 rounded-3xl overflow-hidden">
                  <CardContent className="p-6 flex flex-col items-center text-center space-y-4">
                    <div className="rounded-full bg-blue-100 p-3 animate-float">
                      <Star className="h-6 w-6 text-blue-600" />
                    </div>
                    <h4 className="text-xl font-bold">Servicio</h4>
                    <p className="text-muted-foreground">
                      Nos dedicamos a servir a nuestra comunidad escolar con compromiso y dedicación.
                    </p>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </section>

        <section id="propuestas" className="w-full py-12 md:py-24 lg:py-32 bg-blue-50 relative">
          <Confetti />
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <Badge className="bg-gradient-to-r from-blue-400 to-blue-600 text-white hover:from-blue-500 hover:to-blue-700">
                  Nuestras Ideas
                </Badge>
                <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl bg-clip-text text-transparent bg-gradient-to-r from-blue-500 to-blue-600">
                  Propuestas Divertidas
                </h2>
                <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  Iniciativas pensadas para mejorar nuestra experiencia escolar y desarrollar nuestras habilidades.
                </p>
              </div>
            </div>
            <Tabs defaultValue="general" className="mt-12">
              <TabsList className="grid w-full grid-cols-3 mb-8 rounded-full overflow-hidden">
                <TabsTrigger
                  value="general"
                  className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-blue-500 data-[state=active]:to-blue-600 data-[state=active]:text-white"
                >
                  Colegio en General
                </TabsTrigger>
                <TabsTrigger
                  value="secundaria"
                  className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-blue-500 data-[state=active]:to-blue-600 data-[state=active]:text-white"
                >
                  6to Primaria - 5to Secundaria
                </TabsTrigger>
                <TabsTrigger
                  value="primaria"
                  className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-blue-500 data-[state=active]:to-blue-600 data-[state=active]:text-white"
                >
                  Inicial - 5to Primaria
                </TabsTrigger>
              </TabsList>
              <TabsContent value="general" className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  <ProposalCard
                    title="ASIS Creamos"
                    description="Creación de clubes extracurriculares quincenales para desarrollar talentos e intereses diversos."
                    icon="Star"
                    color="blue"
                  />
                  <ProposalCard
                    title="Not So High School Musical"
                    description="Organización de una obra musical navideña como evento de cierre del año escolar."
                    icon="Music"
                    color="blue"
                  />
                  <ProposalCard
                    title="Gymkhana"
                    description="Actividades deportivas entre promociones al cierre de cada bimestre para fomentar el compañerismo."
                    icon="Trophy"
                    color="blue"
                  />
                  <ProposalCard
                    title="Mural Estudiantil"
                    description="Espacio visible para difundir información de manera accesible y atractiva, administrado por el Consejo Estudiantil."
                    icon="Palette"
                    color="blue"
                  />
                  <ProposalCard
                    title="Memorias Digitales"
                    description="Revista mensual con fotos de eventos y actividades destacando la participación estudiantil."
                    icon="Camera"
                    color="blue"
                  />
                  <ProposalCard
                    title="Redes con ASIS-tencia"
                    description="Comité estudiantil que apoyará en la gestión de redes sociales del colegio bajo supervisión."
                    icon="Share2"
                    color="blue"
                  />
                  <ProposalCard
                    title="La Zona Free"
                    description="Espacio para quedarse a estudiar después de clases con ambiente tranquilo y recursos disponibles."
                    icon="Building"
                    color="blue"
                  />
                  <ProposalCard
                    title="Eco Fashion"
                    description="Curso de diseño sostenible donde estudiantes crearán vestuarios con materiales reciclables."
                    icon="Palette"
                    color="blue"
                  />
                </div>
              </TabsContent>
              <TabsContent value="secundaria" className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  <ProposalCard
                    title="PRESS"
                    description="Periódico Reflexivo Estudiantil Solidario y Salvadorino con noticias, artículos y contenido creado por estudiantes."
                    icon="Newspaper"
                    color="blue"
                  />
                  <ProposalCard
                    title="Telestudiantes"
                    description="Espacio de noticias audiovisuales presentado mensualmente por estudiantes."
                    icon="Video"
                    color="blue"
                  />
                  <ProposalCard
                    title="Red de Estudiantes"
                    description="Programa de tutorías donde estudiantes mayores ayudan a los menores en diferentes materias."
                    icon="Users"
                    color="blue"
                  />
                  <ProposalCard
                    title="Te Vendo Mi Pulga"
                    description="Feria del emprendimiento y de pulgas para presentar proyectos y productos propios."
                    icon="Briefcase"
                    color="blue"
                  />
                  <ProposalCard
                    title="Mini Pasantías"
                    description="Programa donde los alumnos pueden ser asistentes temporales en diferentes áreas del colegio."
                    icon="GraduationCap"
                    color="blue"
                  />
                  <ProposalCard
                    title="Día sin Etiquetas"
                    description="Actividad mensual para fomentar nuevas amistades más allá de los grupos habituales."
                    icon="Tag"
                    color="blue"
                  />
                  <ProposalCard
                    title="Potenciar la Feria de Matemática"
                    description="Dar mayor relevancia a la Feria de Matemática como espacio para la innovación y resolución de problemas."
                    icon="Star"
                    color="blue"
                  />
                  <ProposalCard
                    title="Regreso de la Escuela de Líderes"
                    description="Programa donde exalumnos y estudiantes de 5to ofrecen charlas dinámicas a alumnos de 1ro y 2do."
                    icon="Users"
                    color="blue"
                  />
                </div>
              </TabsContent>
              <TabsContent value="primaria" className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  <ProposalCard
                    title="Yo Quiero Ser"
                    description="Actividad especial donde los niños se disfrazan de lo que quieren ser de grandes para el Día del Maestro."
                    icon="Sparkles"
                    color="blue"
                  />
                  <ProposalCard
                    title="Open House Salvadorino"
                    description="Día de puertas abiertas donde los alumnos representan íconos de la cultura británica."
                    icon="Globe"
                    color="blue"
                  />
                  <ProposalCard
                    title="Divercity"
                    description="Experiencia inmersiva donde los alumnos pueden experimentar diferentes profesiones."
                    icon="Building"
                    color="blue"
                  />
                  <ProposalCard
                    title="Actuando Ando"
                    description="Pequeñas escenas teatrales durante los recreos para abordar temas como el bullying."
                    icon="Theater"
                    color="blue"
                  />
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </section>

        <section
          id="rincon-de-esnupi"
          className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-b from-white to-blue-50"
        >
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <Badge className="bg-gradient-to-r from-blue-400 to-blue-600 text-white hover:from-blue-500 hover:to-blue-700">
                  Nuestra Mascota
                </Badge>
                <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl bg-clip-text text-transparent bg-gradient-to-r from-blue-500 to-blue-600">
                  El Rincón de Esnupi
                </h2>
                <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  Conoce a Esnupi 🍐, nuestra mascota oficial con vibes tranquilas y un corazón enorme.
                </p>
              </div>
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mt-12 items-center">
              <div className="flex justify-center lg:justify-end">
                <div className="relative w-80 h-80 md:w-96 md:h-96">
                  <Image
                    src="/images/mascota.png"
                    alt="Esnupi"
                    width={400}
                    height={400}
                    className="object-contain rounded-full border-4 border-blue-300 shadow-lg bg-white p-4"
                  />
                </div>
              </div>
              <div className="space-y-6">
                <div className="bg-white p-6 rounded-2xl shadow-md relative border-4 border-blue-200">
                  <div className="absolute -top-6 -left-6 bg-blue-500 rounded-full p-2 shadow-lg">
                    <Star className="h-6 w-6 text-white" />
                  </div>
                  <h3 className="text-xl font-bold mb-4 text-blue-700">¡Hola! Soy Esnupi 🍐</h3>
                  <p className="text-muted-foreground">
                    Siempre estoy listo para darlo todo, dentro y fuera del campo. Me encanta jugar, pero más aún ver a
                    mi equipo feliz, reírnos juntos y animar a quien lo necesite. Para mí, lo más importante no es
                    ganar, sino que todos se sientan parte de algo bonito. No soy de los que gritan todo el tiempo, pero
                    cuando hablo, levanto el ánimo. Tengo ese tipo de actitud que hace que todos se sientan parte del
                    equipo.
                  </p>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <Card className="border-2 border-blue-200 rounded-xl hover:shadow-lg transition-all duration-200 hover:-translate-y-1">
                    <CardContent className="p-4">
                      <h4 className="font-medium text-sm text-muted-foreground">Signo Zodiacal</h4>
                      <p className="font-bold">Cáncer e ISFJ</p>
                    </CardContent>
                  </Card>
                  <Card className="border-2 border-blue-200 rounded-xl hover:shadow-lg transition-all duration-200 hover:-translate-y-1">
                    <CardContent className="p-4">
                      <h4 className="font-medium text-sm text-muted-foreground">Pelis Favoritas</h4>
                      <p className="font-bold">Toy Story, Mi Villano Favorito, Cómo entrenar a tu dragón</p>
                    </CardContent>
                  </Card>
                  <Card className="border-2 border-blue-200 rounded-xl hover:shadow-lg transition-all duration-200 hover:-translate-y-1">
                    <CardContent className="p-4">
                      <h4 className="font-medium text-sm text-muted-foreground">Series Favoritas</h4>
                      <p className="font-bold">Bluey, Bob Esponja, Snoopy, Glee</p>
                    </CardContent>
                  </Card>
                  <Card className="border-2 border-blue-200 rounded-xl hover:shadow-lg transition-all duration-200 hover:-translate-y-1">
                    <CardContent className="p-4">
                      <h4 className="font-medium text-sm text-muted-foreground">Lema</h4>
                      <p className="font-bold">"No solo jugamos, también dejamos huella."</p>
                    </CardContent>
                  </Card>
                </div>
                <div className="bg-white p-6 rounded-2xl shadow-md border-2 border-blue-200">
                  <h4 className="font-bold text-lg text-blue-700 mb-2">Más sobre Esnupi</h4>
                  <ul className="space-y-2 text-muted-foreground">
                    <li>• Aún llora cuando Woody dice adiós en Toy Story.</li>
                    <li>• Su gusto culposo es The Peanuts Movie y la canción "Better When I'm Dancin'".</li>
                    <li>• Ama los musicales y podría hablar de ellos todo el día.</li>
                    <li>• Manda stickers de perritos tiernos porque sí y le gusta escribir en su diario.</li>
                    <li>
                      • Representa el compañerismo, el respeto y las ganas de seguir creciendo sin perder la esencia.
                    </li>
                    <li>• Esnupi es como tú, ¡busca cambios!</li>
                  </ul>
                </div>
              </div>
            </div>
            <div className="mt-16">
              <div className="flex flex-col items-center justify-center space-y-4 text-center mb-8">
                <h3 className="text-2xl font-bold">Diario de Esnupi</h3>
                <p className="max-w-[700px] text-muted-foreground">
                  Pensamientos, reflexiones y el sentir diario de nuestra mascota.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <div className="bg-white rounded-xl overflow-hidden shadow-lg border-2 border-blue-200 hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
                  <div className="bg-yellow-500 p-4 flex justify-between items-center">
                    <h4 className="text-white font-bold">Mood: Empresnupi capitalista</h4>
                    <span className="text-2xl">💰</span>
                  </div>
                  <div className="p-6">
                    <p className="italic text-gray-700">
                      "Hoy me ofrecieron una galleta si decía que voten por ASIS. Acepté. Y pedí otra por cada voto."
                    </p>
                    <div className="flex justify-end mt-4">
                      <div className="bg-yellow-100 rounded-full px-3 py-1 text-xs font-medium text-yellow-600">
                        Día #42
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-white rounded-xl overflow-hidden shadow-lg border-2 border-blue-200 hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
                  <div className="bg-green-500 p-4 flex justify-between items-center">
                    <h4 className="text-white font-bold">Mood: Esnupi aprobado con 20 en estrategia electoral</h4>
                    <span className="text-2xl">🧠</span>
                  </div>
                  <div className="p-6">
                    <p className="italic text-gray-700">
                      "Fui al laboratorio de ciencias a convencer a un grupo de estudiantes inteligentes. Salí con dos
                      fórmulas, una teoría y cinco votos."
                    </p>
                    <div className="flex justify-end mt-4">
                      <div className="bg-green-100 rounded-full px-3 py-1 text-xs font-medium text-green-600">
                        Día #45
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-white rounded-xl overflow-hidden shadow-lg border-2 border-blue-200 hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
                  <div className="bg-purple-500 p-4 flex justify-between items-center">
                    <h4 className="text-white font-bold">Mood: Esnupi reguetonero frustrado</h4>
                    <span className="text-2xl">🎵</span>
                  </div>
                  <div className="p-6">
                    <p className="italic text-gray-700">
                      "Intenté escribir una canción para ASIS. Rimaba 'votar' con 'ganar' y 'Esnupi' con 'coolpi'.
                      Conclusión: no me dedico a la música."
                    </p>
                    <div className="flex justify-end mt-4">
                      <div className="bg-purple-100 rounded-full px-3 py-1 text-xs font-medium text-purple-600">
                        Día #48
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-white rounded-xl overflow-hidden shadow-lg border-2 border-blue-200 hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
                  <div className="bg-blue-500 p-4 flex justify-between items-center">
                    <h4 className="text-white font-bold">Mood: Esnupi mediador profesional</h4>
                    <span className="text-2xl">🤝</span>
                  </div>
                  <div className="p-6">
                    <p className="italic text-gray-700">
                      "Salón dividido entre los que quieren exponer y los que quieren desaparecer. Y en el medio... yo,
                      con mi cartel de ASIS en la mano."
                    </p>
                    <div className="flex justify-end mt-4">
                      <div className="bg-blue-100 rounded-full px-3 py-1 text-xs font-medium text-blue-600">
                        Día #51
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-white rounded-xl overflow-hidden shadow-lg border-2 border-blue-200 hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
                  <div className="bg-red-500 p-4 flex justify-between items-center">
                    <h4 className="text-white font-bold">Mood: Esnupi legalmente confundido, pero educado</h4>
                    <span className="text-2xl">📜</span>
                  </div>
                  <div className="p-6">
                    <p className="italic text-gray-700">
                      "La gente votando sin leer nada me recuerda a mí aceptando los términos y condiciones de Mundo
                      Gaturro. Por eso ASIS lo explica todo, bebé."
                    </p>
                    <div className="flex justify-end mt-4">
                      <div className="bg-red-100 rounded-full px-3 py-1 text-xs font-medium text-red-600">Día #54</div>
                    </div>
                  </div>
                </div>

                <div className="bg-white rounded-xl overflow-hidden shadow-lg border-2 border-blue-200 hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
                  <div className="bg-orange-500 p-4 flex justify-between items-center">
                    <h4 className="text-white font-bold">Mood: Esnupi involuntariamente visionario</h4>
                    <span className="text-2xl">🌪️</span>
                  </div>
                  <div className="p-6">
                    <p className="italic text-gray-700">
                      "Hice un cartel con letras gigantes de ASIS. El viento se lo llevó. Ahora hacemos campaña aérea."
                    </p>
                    <div className="flex justify-end mt-4">
                      <div className="bg-orange-100 rounded-full px-3 py-1 text-xs font-medium text-orange-600">
                        Día #57
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex justify-center mt-8">
                <Button variant="outline" className="gap-2 rounded-full animate-bounce">
                  Ver más entradas <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
        </section>

        <section id="objetivos" className="w-full py-12 md:py-24 lg:py-32 bg-blue-600 text-white">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl">Nuestros Objetivos</h2>
                <p className="max-w-[900px] text-blue-100 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  Trabajamos con objetivos claros para mejorar nuestra comunidad escolar.
                </p>
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-12">
              <Card className="bg-white/10 border-2 border-white/20 rounded-xl overflow-hidden hover:bg-white/20 transition-all duration-300">
                <CardContent className="p-6">
                  <h3 className="text-xl font-bold mb-4 text-white">Objetivo General</h3>
                  <p className="text-blue-100">
                    Integrar al alumnado escolar del CEP Mixto Cristo Salvador por medio de propuestas que llamen a la
                    acción social y solidaria, y al servicio de nuestros pares, relacionado con los valores capuchinos
                    de fraternidad y minoridad.
                  </p>
                </CardContent>
              </Card>
              <Card className="bg-white/10 border-2 border-white/20 rounded-xl overflow-hidden hover:bg-white/20 transition-all duration-300">
                <CardContent className="p-6">
                  <h3 className="text-xl font-bold mb-4 text-white">Objetivos Específicos</h3>
                  <ul className="text-blue-100 space-y-2">
                    <li>• Fomentar una mentalidad emprendedora y orientada hacia la proyección profesional.</li>
                    <li>
                      • Implementar sistemas de aprendizaje y retroalimentación sostenidos por los propios alumnos.
                    </li>
                    <li>• Potenciar los recursos vigentes en el colegio y gestionar nuevos apoyos.</li>
                  </ul>
                </CardContent>
              </Card>
              <Card className="bg-white/10 border-2 border-white/20 rounded-xl overflow-hidden hover:bg-white/20 transition-all duration-300">
                <CardContent className="p-6">
                  <h3 className="text-xl font-bold mb-4 text-white">Nuestro Enfoque</h3>
                  <p className="text-blue-100">
                    Nos centramos en los pilares de la explotación de habilidades blandas, reconocimiento de talentos,
                    vida profesional y universitaria, aprovechamiento de recursos y salvadorino como emprendedor.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>
      </main>
      <footer className="w-full border-t py-6 md:py-0 bg-gradient-to-r from-blue-500 to-blue-600 text-white">
        <div className="container flex flex-col md:flex-row items-center justify-between gap-4 md:h-16 px-4 md:px-6">
          <p className="text-sm">
            © 2024 ASIS - Acción Solidaria, Integración y Servicio. Todos los derechos reservados.
          </p>
          <div className="flex items-center gap-4">
            <Link href="#" className="text-sm font-medium hover:underline underline-offset-4">
              Instagram
            </Link>
            <Link href="#" className="text-sm font-medium hover:underline underline-offset-4">
              TikTok
            </Link>
            <Link href="#" className="text-sm font-medium hover:underline underline-offset-4">
              Contacto
            </Link>
          </div>
        </div>
      </footer>
    </div>
  )
}
