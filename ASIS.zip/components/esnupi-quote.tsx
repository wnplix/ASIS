"use client"

import { Card, CardContent } from "@/components/ui/card"
import { motion } from "framer-motion"

interface EsnupiQuoteProps {
  quote: string
  date: string
  mood: string
  emoji?: string
  color?: string
}

export function EsnupiQuote({ quote, date, mood, emoji = getMoodEmoji(mood), color = "blue" }: EsnupiQuoteProps) {
  const bgColor = getBgColor(color)
  const borderColor = getBorderColor(color)
  const textColor = getTextColor(color)

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      whileHover={{ scale: 1.02 }}
    >
      <Card className={`overflow-hidden border-4 ${borderColor} rounded-2xl shadow-lg`}>
        <CardContent className={`p-6 ${bgColor}`}>
          <div className="flex justify-between items-start mb-4">
            <div>
              <p className="text-sm text-gray-500 font-medium">{date}</p>
              <p className={`text-sm font-bold ${textColor}`}>Mood: {mood}</p>
            </div>
            <motion.div
              className="text-3xl"
              animate={{
                rotate: [0, 10, -10, 10, 0],
                scale: [1, 1.2, 1, 1.2, 1],
              }}
              transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY, repeatDelay: 1 }}
            >
              {emoji}
            </motion.div>
          </div>
          <div className="bg-white/70 p-4 rounded-xl shadow-inner">
            <p className="italic text-lg">{quote}</p>
          </div>
          <div className="flex justify-end mt-3">
            <div className="bg-white rounded-full px-3 py-1 text-sm font-medium shadow-sm">- Esnupi 🍐</div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  )
}

function getMoodEmoji(mood: string): string {
  const moods: Record<string, string> = {
    Feliz: "😊",
    Pensativo: "🤔",
    Motivador: "💪",
    Cansado: "😴",
    Emocionado: "🤩",
    Preocupado: "😟",
  }

  return moods[mood] || "😊"
}

function getBgColor(color: string): string {
  const colors: Record<string, string> = {
    blue: "bg-gradient-to-br from-blue-50 to-blue-100",
    green: "bg-gradient-to-br from-green-50 to-blue-50",
    purple: "bg-gradient-to-br from-purple-50 to-blue-50",
    pink: "bg-gradient-to-br from-pink-50 to-blue-50",
    yellow: "bg-gradient-to-br from-yellow-50 to-blue-50",
  }

  return colors[color] || colors.blue
}

function getBorderColor(color: string): string {
  const colors: Record<string, string> = {
    blue: "border-blue-300",
    green: "border-green-300",
    purple: "border-purple-300",
    pink: "border-pink-300",
    yellow: "border-yellow-300",
  }

  return colors[color] || colors.blue
}

function getTextColor(color: string): string {
  const colors: Record<string, string> = {
    blue: "text-blue-600",
    green: "text-green-600",
    purple: "text-purple-600",
    pink: "text-pink-600",
    yellow: "text-yellow-600",
  }

  return colors[color] || colors.blue
}
