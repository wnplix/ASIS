"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { motion } from "framer-motion"

export function MoodSelector() {
  const [selectedMood, setSelectedMood] = useState<string | null>(null)

  const moods = [
    { name: "Feliz", emoji: "😊" },
    { name: "Pensativo", emoji: "🤔" },
    { name: "Motivador", emoji: "💪" },
    { name: "Cansado", emoji: "😴" },
    { name: "Emocionado", emoji: "🤩" },
    { name: "Preocupado", emoji: "😟" },
  ]

  return (
    <div className="bg-white p-6 rounded-2xl shadow-lg border-4 border-dashed border-blue-300">
      <h4 className="font-bold mb-4 text-center text-lg text-blue-700">¿Cómo se siente Esnupi hoy? 🤔</h4>
      <div className="grid grid-cols-3 md:grid-cols-6 gap-3">
        {moods.map((mood) => (
          <motion.div
            key={mood.name}
            whileHover={{ scale: 1.1, rotate: [-2, 2, -2, 0] }}
            whileTap={{ scale: 0.95 }}
            transition={{ duration: 0.3 }}
          >
            <Button
              variant={selectedMood === mood.name ? "default" : "outline"}
              className={`w-full h-full flex flex-col items-center p-3 rounded-xl border-2 ${
                selectedMood === mood.name
                  ? "bg-gradient-to-r from-blue-400 to-blue-500 border-blue-500 text-white"
                  : "border-gray-200"
              }`}
              onClick={() => setSelectedMood(mood.name)}
            >
              <span className="text-3xl mb-1">{mood.emoji}</span>
              <span className="text-xs font-bold">{mood.name}</span>
            </Button>
          </motion.div>
        ))}
      </div>
      {selectedMood && (
        <motion.div
          className="mt-4 text-center bg-blue-100 p-3 rounded-xl border-2 border-blue-300"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
        >
          <p className="text-sm font-medium text-blue-800">
            ¡Hoy Esnupi está <span className="font-bold">{selectedMood.toLowerCase()}</span>!
            {selectedMood === "Feliz" && " ¡Está saltando de alegría! 🎉"}
            {selectedMood === "Pensativo" && " ¡Está planeando algo genial! 💭"}
            {selectedMood === "Motivador" && " ¡Quiere animar a todos! 🔥"}
            {selectedMood === "Cansado" && " ¡Necesita un descanso después de tanta diversión! 💤"}
            {selectedMood === "Emocionado" && " ¡No puede esperar para compartir sus ideas! ✨"}
            {selectedMood === "Preocupado" && " ¡Quiere asegurarse de que todos estén bien! 💙"}
          </p>
        </motion.div>
      )}
    </div>
  )
}
