"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import Image from "next/image"
import { motion } from "framer-motion"
import { BouncingButton } from "@/components/bouncing-button"

export function FunHeader() {
  const [isScrolled, setIsScrolled] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50)
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  return (
    <motion.header
      className={`sticky top-0 z-40 w-full backdrop-blur transition-all duration-300 ${
        isScrolled ? "bg-white/95 shadow-md" : "bg-transparent"
      }`}
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <div className="container flex h-16 items-center justify-between">
        <motion.div className="flex gap-6 md:gap-10 items-center" whileHover={{ scale: 1.05 }}>
          <Link href="/" className="flex items-center space-x-2">
            <motion.div
              animate={{ rotate: [0, 10, -10, 0] }}
              transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY }}
            >
              <Image src="/images/logo.png" alt="Logo ASIS" width={48} height={32} className="h-8 w-auto" />
            </motion.div>
            <motion.span
              className="inline-block font-bold text-xl bg-clip-text text-transparent bg-gradient-to-r from-blue-500 to-blue-600"
              animate={{
                color: ["#4FACFE", "#00F2FE", "#4FACFE"],
              }}
              transition={{ duration: 3, repeat: Number.POSITIVE_INFINITY }}
            >
              ASIS
            </motion.span>
          </Link>
          <nav className="hidden md:flex gap-6">
            {["Inicio", "Conócenos", "Propuestas", "Rincón de Esnupi"].map((item, i) => (
              <motion.div
                key={item}
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.95 }}
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
              >
                <Link
                  href={`#${item.toLowerCase().replace("ó", "o").replace(" de ", "-").replace(" ", "-")}`}
                  className="text-sm font-medium transition-colors hover:text-primary relative group"
                >
                  {item}
                  <span className="absolute -bottom-1 left-0 w-0 h-1 bg-gradient-to-r from-blue-500 to-blue-600 group-hover:w-full transition-all duration-300"></span>
                </Link>
              </motion.div>
            ))}
          </nav>
        </motion.div>
        <div className="flex items-center gap-4">
          <BouncingButton />
        </div>
      </div>
    </motion.header>
  )
}
