"use client"

import { Card, CardContent } from "@/components/ui/card"
import {
  Star,
  Music,
  Trophy,
  Palette,
  Camera,
  Share2,
  Newspaper,
  Video,
  Users,
  Briefcase,
  GraduationCap,
  Tag,
  Sparkles,
  Globe,
  Building,
  Theater,
  type LucideIcon,
} from "lucide-react"
import { motion } from "framer-motion"

interface ProposalCardProps {
  title: string
  description: string
  icon: string
  color?: string
}

export function ProposalCard({ title, description, icon, color = "blue" }: ProposalCardProps) {
  const IconComponent = getIcon(icon)
  const bgColor = getBgColor(color)
  const borderColor = getBorderColor(color)
  const iconColor = getIconColor(color)
  const textColor = getTextColor(color)

  return (
    <motion.div
      whileHover={{ y: -8, scale: 1.02 }}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
    >
      <Card
        className={`h-full hover:shadow-xl transition-all duration-300 border-4 ${borderColor} rounded-2xl overflow-hidden`}
      >
        <CardContent className={`p-6 flex flex-col h-full ${bgColor}`}>
          <motion.div
            className={`rounded-full ${iconColor} p-3 w-fit mb-4`}
            whileHover={{ rotate: [0, -10, 10, -10, 0] }}
            transition={{ duration: 0.5 }}
          >
            <IconComponent className={`h-6 w-6 ${textColor}`} />
          </motion.div>
          <h3 className={`text-xl font-bold mb-2 ${textColor}`}>{title}</h3>
          <p className="text-gray-700 flex-grow">{description}</p>
        </CardContent>
      </Card>
    </motion.div>
  )
}

function getIcon(iconName: string): LucideIcon {
  const icons: Record<string, LucideIcon> = {
    Star,
    Music,
    Trophy,
    Palette,
    Camera,
    Share2,
    Newspaper,
    Video,
    Users,
    Briefcase,
    GraduationCap,
    Tag,
    Sparkles,
    Globe,
    Building,
    Theater,
  }

  return icons[iconName] || Star
}

function getBgColor(color: string): string {
  const colors: Record<string, string> = {
    blue: "bg-gradient-to-br from-white to-blue-50",
    green: "bg-gradient-to-br from-white to-green-50",
    red: "bg-gradient-to-br from-white to-red-50",
    yellow: "bg-gradient-to-br from-white to-yellow-50",
    purple: "bg-gradient-to-br from-white to-purple-50",
    pink: "bg-gradient-to-br from-white to-pink-50",
    orange: "bg-gradient-to-br from-white to-orange-50",
    teal: "bg-gradient-to-br from-white to-teal-50",
  }

  return colors[color] || colors.blue
}

function getBorderColor(color: string): string {
  const colors: Record<string, string> = {
    blue: "border-blue-300",
    green: "border-green-300",
    red: "border-red-300",
    yellow: "border-yellow-300",
    purple: "border-purple-300",
    pink: "border-pink-300",
    orange: "border-orange-300",
    teal: "border-teal-300",
  }

  return colors[color] || colors.blue
}

function getIconColor(color: string): string {
  const colors: Record<string, string> = {
    blue: "bg-blue-100",
    green: "bg-green-100",
    red: "bg-red-100",
    yellow: "bg-yellow-100",
    purple: "bg-purple-100",
    pink: "bg-pink-100",
    orange: "bg-orange-100",
    teal: "bg-teal-100",
  }

  return colors[color] || colors.blue
}

function getTextColor(color: string): string {
  const colors: Record<string, string> = {
    blue: "text-blue-600",
    green: "text-green-600",
    red: "text-red-600",
    yellow: "text-yellow-600",
    purple: "text-purple-600",
    pink: "text-pink-600",
    orange: "text-orange-600",
    teal: "text-teal-600",
  }

  return colors[color] || colors.blue
}
