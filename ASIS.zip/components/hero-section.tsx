"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { motion } from "framer-motion"
import Link from "next/link"
import Image from "next/image"
import { Sparkles, Star } from "lucide-react"

export function HeroSection() {
  const [isVisible, setIsVisible] = useState(false)
  const [bounce, setBounce] = useState(false)

  useEffect(() => {
    setIsVisible(true)
    const interval = setInterval(() => {
      setBounce((prev) => !prev)
    }, 2000)
    return () => clearInterval(interval)
  }, [])

  return (
    <div className="container px-4 md:px-6">
      <div className="grid gap-6 lg:grid-cols-[1fr_400px] lg:gap-12 xl:grid-cols-[1fr_500px] items-center">
        <motion.div
          className="flex flex-col justify-center space-y-4"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: isVisible ? 1 : 0, y: isVisible ? 0 : 20 }}
          transition={{ duration: 0.5 }}
        >
          <div className="space-y-2">
            <motion.div
              initial={{ scale: 0.8 }}
              animate={{ scale: [0.8, 1.1, 1] }}
              transition={{ duration: 0.5 }}
              className="inline-block"
            >
              <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl xl:text-6xl/none bg-gradient-to-r from-blue-500 via-blue-600 to-blue-700 text-transparent bg-clip-text">
                ¡ASIS: Acción Solidaria, Integración y Servicio! 🌊
              </h1>
            </motion.div>
            <p className="max-w-[600px] text-muted-foreground md:text-xl">
              Somos un equipo comprometido con la integración del alumnado escolar del CEP Mixto Cristo Salvador por
              medio de propuestas que llamen a la acción social y solidaria, y al servicio de nuestros pares.
            </p>
          </div>
          <div className="flex flex-col gap-2 min-[400px]:flex-row">
            <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
              <Button
                asChild
                size="lg"
                className="bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 rounded-full text-lg font-bold shadow-lg"
              >
                <Link href="#propuestas">
                  <Star className="mr-2 h-5 w-5" /> ¡Nuestras Ideas Geniales!
                </Link>
              </Button>
            </motion.div>
            <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
              <Button
                asChild
                size="lg"
                variant="outline"
                className="border-2 border-blue-400 hover:bg-blue-100 rounded-full text-lg font-bold"
              >
                <Link href="#conocenos">¡Conoce a Nuestro Equipo!</Link>
              </Button>
            </motion.div>
          </div>
        </motion.div>
        <motion.div
          className="mx-auto lg:mx-0 relative"
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: isVisible ? 1 : 0, scale: isVisible ? 1 : 0.9 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          <div className="relative w-full h-[400px] overflow-hidden rounded-3xl shadow-xl border-4 border-blue-300">
            <Image
              src="/images/votaporasis.jpg"
              alt="Esnupi ayudando a estudiar"
              width={500}
              height={400}
              className="object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-blue-600/70 to-transparent flex items-end p-6">
              <div className="text-white">
                <p className="text-2xl font-bold">¡Vota por ASIS! ✨</p>
                <p className="text-lg">¡Ideas divertidas para un cole increíble!</p>
              </div>
            </div>
          </div>
          <motion.div
            className="absolute -bottom-6 -right-6 bg-gradient-to-r from-blue-300 to-blue-400 rounded-full p-4 shadow-lg border-4 border-white"
            initial={{ rotate: -5 }}
            animate={{
              rotate: bounce ? 5 : -5,
              y: bounce ? -5 : 5,
            }}
            transition={{ duration: 1, ease: "easeInOut" }}
          >
            <div className="flex items-center gap-2">
              <Sparkles className="h-6 w-6 text-white" />
              <p className="text-base font-bold text-white">¡Esnupi te invita a participar!</p>
            </div>
          </motion.div>
          <motion.div
            className="absolute -top-4 -left-4 bg-gradient-to-r from-blue-300 to-blue-400 rounded-full p-3 shadow-lg border-4 border-white"
            animate={{
              scale: [1, 1.1, 1],
            }}
            transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY }}
          >
            <p className="text-sm font-bold text-white">¡Haz clic! 👆</p>
          </motion.div>
        </motion.div>
      </div>
    </div>
  )
}
